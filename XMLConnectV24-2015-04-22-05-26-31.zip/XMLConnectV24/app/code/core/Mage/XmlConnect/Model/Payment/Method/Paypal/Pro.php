<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * PayPal Website Payments Pro implementation for payment method instances
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Model_Payment_Method_Paypal_Pro extends Mage_Paypal_Model_Pro
{
    /**
     * Config mode type
     *
     * @var string
     */
    protected $_configType = 'xmlconnect/payment_method_paypal_config';
}
