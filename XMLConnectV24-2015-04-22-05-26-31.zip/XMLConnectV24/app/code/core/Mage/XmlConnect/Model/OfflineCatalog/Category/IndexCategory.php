<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Xmlconnect offline catalog index category model
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Model_OfflineCatalog_Category_IndexCategory extends Mage_XmlConnect_Model_OfflineCatalog_Abstract
{
    /**
     * Index category url
     */
    const CATEGORY_INDEX_URL = 'xmlconnect/catalog/category/';

    /**
     * Return category block
     *
     * @param Mage_XmlConnect_Helper_OfflineCatalog $exportHelper
     * @return Mage_Core_Block_Abstract
     */
    public function getLayoutBlock($exportHelper)
    {
        return $exportHelper->getBlock('xmlconnect.catalog.category');
    }

    /**
     * Return index category url
     *
     * @return string
     */
    protected function _getActionUrl()
    {
        return Mage::getBaseUrl() . self::CATEGORY_INDEX_URL;
    }
}
