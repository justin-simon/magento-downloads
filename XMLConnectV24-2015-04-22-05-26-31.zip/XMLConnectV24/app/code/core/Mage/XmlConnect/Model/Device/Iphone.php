<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * XmlConnect iPhone device model
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Model_Device_Iphone extends Mage_XmlConnect_Model_Device_Abstract
{
    /**
     * Portrait banner image type
     */
    const IMAGE_TYPE_PORTRAIT_BANNER = 'iphone_portrait_banner';

    /**
     * Portrait background image type
     */
    const IMAGE_TYPE_PORTRAIT_BACKGROUND = 'iphone_portrait_background';

    /**
     * iPhone default scale used for calculation rate
     */
    const DEFAULT_SCALE = 320;

    /**
     * iPhone default screen size
     */
    const SCREEN_SIZE_DEFAULT   = '320x480';

    /**
     * Portrait preview banner width
     */
    const PREVIEW_PORTRAIT_BANNER_WIDTH = '320';

    /**
     * Portrait preview banner height
     */
    const PREVIEW_PORTRAIT_BANNER_HEIGHT = '230';

    /**
     * Device specific image size configuration
     *
     * @var array
     */
    protected $_imageSizeConfiguration = array(
        self::IMAGE_TYPE_ICON => array('width' => 35, 'height' => 35),
        self::IMAGE_TYPE_PORTRAIT_BANNER => array('width' => 320, 'height' => 230),
        self::IMAGE_TYPE_PORTRAIT_BACKGROUND => array('width' => 320, 'height' => 367),
        'content' => array('product_gallery_big' => 560),
    );

    /**
     * Initialize model
     *
     * @param null|Mage_XmlConnect_Model_Application $applicationModel
     */
    public function __construct($applicationModel = null)
    {
        parent::__construct($applicationModel);
    }

    /**
     * Get iPhone default screen size
     *
     * @return string
     */
    public function getDefaultScreenSize()
    {
        return self::SCREEN_SIZE_DEFAULT;
    }

    /**
     * Get iPhone default scale
     *
     * @return int
     */
    public function getDefaultScaleValue()
    {
        return self::DEFAULT_SCALE;
    }

    /**
     * Return image size configuration for device
     *
     * @return array
     */
    protected function _getImageSizeConfiguration()
    {
        return $this->_imageSizeConfiguration;
    }
}
