<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * XmlConnect Model Resource Application Collection
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Model_Resource_Application_Collection extends Mage_Core_Model_Resource_Db_Collection_Abstract
{
    /**
     * Constructor, setting table
     *
     * @return null
     */
    protected function _construct()
    {
        $this->_init('xmlconnect/application');
    }
}
