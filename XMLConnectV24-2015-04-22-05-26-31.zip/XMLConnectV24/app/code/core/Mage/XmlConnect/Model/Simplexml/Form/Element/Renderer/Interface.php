<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Xmlconnect Form field renderer interface
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
interface Mage_XmlConnect_Model_Simplexml_Form_Element_Renderer_Interface
{
    public function render(Mage_XmlConnect_Model_Simplexml_Form_Element_Abstract $element);
}
