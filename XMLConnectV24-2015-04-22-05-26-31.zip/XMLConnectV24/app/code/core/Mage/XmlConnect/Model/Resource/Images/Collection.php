<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * XmlConnect Images resource collection
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_Xmlconnect_Model_Resource_Images_Collection extends Mage_Core_Model_Resource_Db_Collection_Abstract
{
    /**
     * Init resource model
     */
    protected function _construct()
    {
        $this->_init('xmlconnect/images');
    }

    /**
     * Add application filter
     *
     * @param integer $appId
     * @return Mage_Xmlconnect_Model_Images_Collection
     */
    public function addApplicationToFilter($appId)
    {
        $this->addFieldToFilter('application_id', $appId);
        return $this;
    }

    /**
     * Add image type filter
     *
     * @param integer $type
     * @return Mage_Xmlconnect_Model_Images_Collection
     */
    public function addImageTypeToFilter($type)
    {
        $this->addFieldToFilter('image_type', $type);
        return $this;
    }

    /**
     * Set Order by position
     *
     * @return Mage_Xmlconnect_Model_Images_Collection
     */
    public function setPositionOrder()
    {
        $this->setOrder('main_table.order', self::SORT_ORDER_ASC);
        return $this;
    }

    /**
     * Sets a limit count and offset to the query.
     *
     * @param int $count OPTIONAL The number of rows to return.
     * @param int $offset OPTIONAL Start returning after this many rows.
     * @return Mage_Xmlconnect_Model_Resource_Images_Collection
     */
    public function setLimit($count = null, $offset = null)
    {
        $this->getSelect()->limit($count, $offset);
        return $this;
    }
}
