<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Search Catalog Model
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Model_Adminhtml_Search_Catalog extends Varien_Object
{
    /**
     * Load search results
     *
     * @return Mage_XmlConnect_Model_Adminhtml_Search_Catalog
     */
    public function load()
    {
        $arr = array();

        if (!$this->hasStart() || !$this->hasLimit() || !$this->hasQuery()) {
            $this->setResults($arr);
            return $this;
        }

        $collection = Mage::helper('catalogsearch')->getQuery()->getSearchCollection()
            ->addAttributeToSelect('product_id')->addAttributeToSelect('name')->addAttributeToSelect('description')
            ->addAttributeToSelect('image')->addSearchFilter($this->getQuery())->setCurPage($this->getStart())
            ->setPageSize($this->getLimit())->load();

        foreach ($collection as $product) {
            $description = Mage::helper('core')->stripTags($product->getDescription());
            $arr[] = array(
                'id'            => 'product/1/' . $product->getId(),
                'item_id'       => $product->getId(),
                'type'          => Mage_XmlConnect_Model_ImageAction::ACTION_TYPE_PRODUCT,
                'label'         => Mage::helper('adminhtml')->__('Product'),
                'name'          => $product->getName(),
                'image'         => $product->getImage(),
                'description'   => Mage::helper('core/string')->substr($description, 0, 30),
                'url' => Mage::helper('adminhtml')->getUrl('*/catalog_product/edit', array('id' => $product->getId())),
            );
        }
        $this->setResults($arr);
        return $this;
    }
}
