<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Xmlconnect offline catalog gallery model
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Model_OfflineCatalog_Product_Gallery extends Mage_XmlConnect_Model_OfflineCatalog_Abstract
{
    /**
     * Gallery url
     */
    const GALLERY_URL = 'xmlconnect/catalog/productgallery/id/%1$s/';

    /**
     * Return gallery block
     *
     * @param Mage_XmlConnect_Helper_OfflineCatalog $exportHelper
     * @return Mage_Core_Block_Abstract
     */
    public function getLayoutBlock($exportHelper)
    {
        return $exportHelper->getBlock('xmlconnect.catalog.product.gallery');
    }

    /**
     * Return gallery url
     *
     * @return string
     */
    protected function _getActionUrl()
    {
        return sprintf(Mage::getBaseUrl() . self::GALLERY_URL, $this->getProduct()->getId());
    }
}
