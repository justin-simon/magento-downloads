<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Xmlconnect offline catalog review model
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Model_OfflineCatalog_Product_Review extends Mage_XmlConnect_Model_OfflineCatalog_Abstract
{
    /**
     * Review url
     */
    const REVIEW_URL = 'xmlconnect/catalog/productreviews/id/%1$s/';

    /**
     * Return review block
     *
     * @param Mage_XmlConnect_Helper_OfflineCatalog $exportHelper
     * @return Mage_Core_Block_Abstract
     */
    public function getLayoutBlock($exportHelper)
    {
        return $exportHelper->getBlock('xmlconnect.catalog.product.reviews');
    }

    /**
     * Return review url
     *
     * @return mixed
     */
    protected function _getActionUrl()
    {
        return sprintf(Mage::getBaseUrl() . self::REVIEW_URL, $this->getProduct()->getId());
    }
}
