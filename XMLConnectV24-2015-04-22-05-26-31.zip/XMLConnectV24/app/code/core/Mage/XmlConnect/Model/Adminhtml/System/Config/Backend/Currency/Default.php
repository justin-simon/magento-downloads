<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Xmlconnect system config currency model
 *
 * @category    Mage
 * @package     Mage_Xmlconnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Model_Adminhtml_System_Config_Backend_Currency_Default
    extends Mage_Adminhtml_Model_System_Config_Backend_Currency_Default
{
    /**
     * Update all applications "updated at" parameter with current date
     *
     * @return Mage_XmlConnect_Model_Adminhtml_System_Config_Backend_Currency_Default
     */
    protected function _afterSave()
    {
        parent::_afterSave();
        if ($this->isValueChanged()) {
            Mage::getModel('xmlconnect/application')->updateAllAppsUpdatedAtParameter();
        }
        return $this;
    }
}
