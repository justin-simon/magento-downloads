<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Android preview model
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Model_Preview_Android extends Mage_XmlConnect_Model_Preview_Abstract
{
    /**
     * Current device orientation
     *
     * @var string
     */
    protected $_orientation = 'unknown';

    /**
     * Set device orientation
     *
     * @param string $orientation
     * @return Mage_XmlConnect_Model_Preview_Android
     */
    public function setOrientation($orientation)
    {
        $this->_orientation = $orientation;
        return $this;
    }

    /**
     * Get current device orientation
     *
     * @return string
     */
    public function getOrientation()
    {
        return $this->_orientation;
    }

    /**
     * Get application banner image url
     *
     * @return string
     */
    public function getBannerImage()
    {
        $result = array();
        $bannerImages = $this->getImageModel()
            ->getDeviceImagesByType(Mage_XmlConnect_Model_Device_Android::IMAGE_TYPE_PORTRAIT_BANNER);
        if (!empty($bannerImages)) {
            $width  = Mage_XmlConnect_Model_Device_Android::PREVIEW_BANNER_WIDTH;
            $height = Mage_XmlConnect_Model_Device_Android::PREVIEW_BANNER_HEIGHT;
            foreach ($bannerImages as $banner) {
                if (!isset($banner['image_file'])) {
                    continue;
                }
                $result[] = $this->getImageModel()->getCustomSizeImageUrl($banner['image_file'], $width, $height);
            }
        }
        return $result;
    }

    /**
     * We doesn't support background images for android
     *
     * @return false
     */
    public function getBackgroundImage()
    {
        return false;
    }
}
