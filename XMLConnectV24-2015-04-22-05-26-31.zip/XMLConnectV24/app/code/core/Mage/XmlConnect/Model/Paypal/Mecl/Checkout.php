<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * XmlConnect PayPal Mobile Express Checkout Library model
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Model_Paypal_Mecl_Checkout extends Mage_Paypal_Model_Express_Checkout
{
    /**
     * Payment method type
     *
     * @var string
     */
    protected $_methodType = Mage_XmlConnect_Model_Payment_Method_Paypal_Config::METHOD_WPP_MECL;

    /**
     * Set sandbox flag and get api
     *
     * @return Mage_Paypal_Model_Api_Nvp
     */
    protected function _getApi()
    {
        $this->_setSandboxFlag();
        return parent::_getApi();
    }

    /**
     * Set sandbox flag
     *
     * @return Mage_XmlConnect_Model_Paypal_Mecl_Checkout
     */
    protected function _setSandboxFlag()
    {
        $this->_config->sandboxFlag = Mage::helper('payment')
            ->getMethodInstance(Mage_XmlConnect_Model_Payment_Method_Paypal_Config::METHOD_WPP_EXPRESS)
            ->getConfigData('sandbox_flag');
        return $this;
    }
}
