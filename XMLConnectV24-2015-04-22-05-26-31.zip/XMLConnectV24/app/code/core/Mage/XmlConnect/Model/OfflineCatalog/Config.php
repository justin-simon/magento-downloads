<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Xmlconnect offline catalog config model
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Model_OfflineCatalog_Config extends Mage_XmlConnect_Model_OfflineCatalog_Abstract
{
    /**
     * Config url
     */
    const CONFIG_URL = 'Configuration';

    /**
     * Export config data
     *
     * @return Mage_XmlConnect_Model_OfflineCatalog_Config
     */
    public function exportData()
    {
        /** @var $exportHelper Mage_XmlConnect_Helper_OfflineCatalog */
        $exportHelper = Mage::helper('xmlconnect/offlineCatalog');
        Mage::app()->getRequest()->setParam('app_code', $exportHelper->getCurrentDeviceModel()->getCode());
        $exportHelper->addOfflineCatalogData(
            $this->_getActionUrl(), $this->getLayoutBlock($exportHelper)->toHtml()
        );
        return $this;
    }

    /**
     * Return config block
     *
     * @param Mage_XmlConnect_Helper_OfflineCatalog $exportHelper
     * @return Mage_Core_Block_Abstract
     */
    public function getLayoutBlock($exportHelper)
    {
        return $exportHelper->getBlock('xmlconnect.configuration');
    }

    /**
     * Return action url
     *
     * @return string
     */
    protected function _getActionUrl()
    {
        return self::CONFIG_URL;
    }
}
