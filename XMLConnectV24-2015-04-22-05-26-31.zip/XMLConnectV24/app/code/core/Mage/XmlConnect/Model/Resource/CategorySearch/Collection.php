<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Category search collection
 *
 * @category   Mage
 * @package    Mage_XmlConnect
 * @author     Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Model_Resource_CategorySearch_Collection extends Mage_Catalog_Model_Resource_Category_Collection
{
    /**
     * Filter for category collection
     *
     * @var array
     */
    protected $_collectionFilter = array();

    /**
     * Add search query filter
     *
     * @param string $query
     * @return Mage_XmlConnect_Model_Resource_CategorySearch_Collection
     */
    public function addSearchFilter($query)
    {
        $this->_addNameFilter($query)->_addDescriptionFilter($query)
            ->_addUrlKeyFilter($query)->addFieldToFilter($this->getCollectionFilter());

        return $this;
    }

    /**
     * Add name filter
     *
     * @param string $query
     * @return Mage_XmlConnect_Model_Resource_CategorySearch_Collection
     */
    protected function _addNameFilter($query)
    {
        $collectionFilter = $this->getCollectionFilter();
        $collectionFilter[] = array('attribute' => 'name', 'like' => $query . '%');
        $this->setCollectionFilter($collectionFilter);
        return $this;
    }

    /**
     * Add description filter
     *
     * @param string $query
     * @return Mage_XmlConnect_Model_Resource_CategorySearch_Collection
     */
    protected function _addDescriptionFilter($query)
    {
        $collectionFilter = $this->getCollectionFilter();
        $collectionFilter[] = array('attribute' => 'description', 'like' => $query . '%');
        $this->setCollectionFilter($collectionFilter);
        return $this;
    }

    /**
     * Add url key filter
     *
     * @param string $query
     * @return Mage_XmlConnect_Model_Resource_CategorySearch_Collection
     */
    protected function _addUrlKeyFilter($query)
    {
        $collectionFilter = $this->getCollectionFilter();
        $collectionFilter[] = array('attribute' => 'url_key', 'like' => $query . '%');
        $this->setCollectionFilter($collectionFilter);
        return $this;
    }

    /**
     * Set collection filter
     *
     * @param array $collectionFilter
     * @return Mage_XmlConnect_Model_Resource_CategorySearch_Collection
     */
    public function setCollectionFilter($collectionFilter)
    {
        $this->_collectionFilter = $collectionFilter;
        return $this;
    }

    /**
     * Get collection filter
     *
     * @return array
     */
    public function getCollectionFilter()
    {
        return $this->_collectionFilter;
    }
}
