<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Xmlconnect offline catalog home model
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Model_OfflineCatalog_Home extends Mage_XmlConnect_Model_OfflineCatalog_Abstract
{
    /**
     * Home url
     */
    const HOME_URL = 'xmlconnect/index/index/';

    /**
     * Return home block
     *
     * @param Mage_XmlConnect_Helper_OfflineCatalog $exportHelper
     * @return Mage_Core_Block_Abstract
     */
    public function getLayoutBlock($exportHelper)
    {
        return $exportHelper->getBlock('xmlconnect.home');
    }

    /**
     * Return home url
     *
     * @return string
     */
    protected function _getActionUrl()
    {
        return Mage::getBaseUrl() . self::HOME_URL;
    }
}
