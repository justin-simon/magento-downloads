<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Xmlconnect offline catalog category model
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Model_OfflineCatalog_Category_Category extends Mage_XmlConnect_Model_OfflineCatalog_Abstract
{
    /**
     * Category url
     */
    const CATEGORY_URL = 'xmlconnect/catalog/category/id/%1$s/';

    /**
     * Return category block
     *
     * @param Mage_XmlConnect_Helper_OfflineCatalog $exportHelper
     * @return Mage_Core_Block_Abstract
     */
    public function getLayoutBlock($exportHelper)
    {
        return $exportHelper->getBlock('xmlconnect.catalog.category');
    }

    /**
     * Return category url
     *
     * @return string
     */
    protected function _getActionUrl()
    {
        return sprintf(Mage::getBaseUrl() . self::CATEGORY_URL, $this->getCategoryId());
    }
}
