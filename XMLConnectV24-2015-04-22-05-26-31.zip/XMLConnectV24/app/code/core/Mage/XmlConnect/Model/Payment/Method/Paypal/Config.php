<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * PayPal Mobile Express Checkout Library config
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Model_Payment_Method_Paypal_Config extends Mage_Paypal_Model_Config
{
    /**
     * PayPal Website Payments Pro - PayPal Mobile Express Checkout Library
     */
    const METHOD_WPP_MECL = 'paypal_mecl';

    /**
     * Get url for dispatching customer to express checkout start
     *
     * @param string $token
     * @return string
     */
    public function getExpressCheckoutStartUrl($token)
    {
        return $this->getPaypalUrl(array('cmd' => '_express-checkout-mobile', 'token' => $token));
    }

    /**
     * Map any supported payment method into a config path by specified field name
     *
     * @param string $fieldName
     * @return string|null
     */
    protected function _getSpecificConfigPath($fieldName)
    {
        $path = $this->_mapExpressFieldset($fieldName);

        if ($path === null) {
            $path = $this->_mapWppFieldset($fieldName);
        }

        if ($path === null) {
            $path = parent::_getSpecificConfigPath($fieldName);
        }

        return $path;
    }
}
