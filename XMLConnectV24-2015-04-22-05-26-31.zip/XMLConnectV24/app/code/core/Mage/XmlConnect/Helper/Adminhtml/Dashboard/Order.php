<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Dashboard order graph helper
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Helper_Adminhtml_Dashboard_Order extends Mage_Adminhtml_Helper_Dashboard_Order
{
    /**
     * Re-init product collection
     *
     * @return null
     */
    public function initCollection()
    {
        $this->_collection = Mage::getResourceModel('reports/order_collection')
            ->prepareSummary($this->getParam('period'), 0, 0, (bool)$this->getParam('store'));

        if ($this->getParam('store')) {
            $this->_collection->addFieldToFilter('store_id', $this->getParam('store'));
        } elseif (!$this->_collection->isLive()) {
            $this->_collection->addFieldToFilter('store_id', array(
                'eq' => Mage::app()->getStore(Mage_Core_Model_Store::ADMIN_CODE)->getId()
            ));
        }
        $this->_collection->load();
    }

    /**
     * Prepare price to display
     *
     * @param null|string $price
     * @param null|string $storeId
     * @return string
     */
    public function preparePrice($price, $storeId)
    {
        $baseCurrencyCode = (string)Mage::app()->getStore($storeId)->getBaseCurrencyCode();
        return Mage::app()->getLocale()->currency($baseCurrencyCode)->toCurrency($price);
    }
}
