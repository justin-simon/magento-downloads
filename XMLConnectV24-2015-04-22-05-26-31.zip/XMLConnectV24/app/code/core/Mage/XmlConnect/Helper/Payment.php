<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * @deprecated after 1.4.2.0
 */
class Mage_XmlConnect_Helper_Payment extends Mage_Core_Helper_Abstract
{
    /**
     * Return paymentMethod => methodCode array
     *
     * @deprecated after 1.4.2.0
     * @return array
     */
    public function getPaymentMethodCodeList()
    {
        return array();
    }
}
