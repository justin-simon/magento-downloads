<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Xmlconnect templates data update
 *
 * @category    Mage
 * @package     Mage_Xmlconnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */

/* @var $installer Mage_Core_Model_Resource_Setup */
$installer = $this;

$templateTableName = $installer->getTable('xmlconnect/template');
$appCodeField = $installer->getConnection()->tableColumnExists($templateTableName, 'app_code');

if ($appCodeField) {
    /** @var $appModel Mage_XmlConnect_Model_Application */
    $appModel = Mage::getModel('xmlconnect/application');
    /** @var $templateModel Mage_XmlConnect_Model_Template */
    $templateModel = Mage::getModel('xmlconnect/template');

    $select = $templateModel->getResource()->getReadConnection()->select()
        ->from($templateTableName, array('app_code', 'template_id'));

    $result = $templateModel->getResource()->getReadConnection()->fetchAll($select);

    foreach ($result as $rows) {
        if (empty($rows['app_code'])) {
            continue;
        }
        $appModel->loadByCode($rows['app_code']);
        $templateModel->load($rows['template_id']);
        $templateModel->setApplicationId($appModel->getApplicationId());
        $templateModel->save();
    }

    $installer->getConnection()->dropColumn($templateTableName, 'app_code');
}
