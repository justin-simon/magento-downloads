<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

$installer = $this;
/* @var $installer Mage_Core_Model_Resource_Setup */
$installer->startSetup();

$templateTable = $installer->getTable('xmlconnect/template');

$installer->getConnection()->addColumn($templateTable, 'app_code', 'VARCHAR( 32 ) NOT NULL AFTER `id`');
$installer->getConnection()->dropColumn($templateTable, 'app_type');

$installer->endSetup();
