<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Xmlconnect Config data install
 *
 * @category    Mage
 * @package     Mage_Xmlconnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */

/* @var $installer Mage_Core_Model_Resource_Setup */
$installer = $this;

    $configTableName = $installer->getTable('xmlconnect/configData');

    /** @var $configModel Mage_XmlConnect_Model_Application */
    $configModel = Mage::getModel('xmlconnect/configData');
    $select = $configModel->getResource()->getReadConnection()->select()->from(
        $configTableName, array('application_id')
    )->group('application_id')->where('category=?', Mage_XmlConnect_Model_Application::DEPRECATED_CONFIG_FLAG);

    $result = $configModel->getResource()->getReadConnection()->fetchCol($select);

    if (count($result)) {
        Mage::getModel('xmlconnect/images')->dataUpgradeOldConfig($result);
        Mage::getModel('xmlconnect/configData')->pagesUpgradeOldConfig($result);
    }
