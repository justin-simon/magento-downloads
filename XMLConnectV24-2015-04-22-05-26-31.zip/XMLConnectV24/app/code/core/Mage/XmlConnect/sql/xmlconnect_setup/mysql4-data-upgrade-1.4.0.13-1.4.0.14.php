<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Xmlconnect Config data install
 *
 * @category    Mage
 * @package     Mage_Xmlconnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */

/* @var $installer Mage_Core_Model_Resource_Setup */
$installer = $this;

$appTableName = $installer->getTable('xmlconnect/application');

$configField = $installer->getConnection()
    ->tableColumnExists($appTableName, 'configuration');

if ($configField) {
    /** @var $appModel Mage_XmlConnect_Model_Application */
    $appModel = Mage::getModel('xmlconnect/application');
    $select = $appModel->getResource()->getReadConnection()->select()->from(
        $appTableName, array('application_id', 'configuration')
    );

    $result = $appModel->getResource()->getReadConnection()->fetchAll($select);

    foreach ($result as $rows) {
        if (empty($rows['configuration'])) {
            continue;
        }
        $deprecatedConfig = unserialize($rows['configuration']);
        $appModel->getConfigModel()->saveConfig(
            $rows['application_id'],
            $appModel->convertOldConfing($deprecatedConfig),
            Mage_XmlConnect_Model_Application::DEPRECATED_CONFIG_FLAG
        );
    }

    $installer->getConnection()->dropColumn(
        $installer->getTable('xmlconnect/application'), 'configuration'
    );
}
