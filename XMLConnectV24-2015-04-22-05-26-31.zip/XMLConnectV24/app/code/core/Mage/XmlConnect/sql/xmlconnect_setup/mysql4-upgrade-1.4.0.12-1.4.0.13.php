<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/** @var $installer Mage_Core_Model_Resource_Setup */
$installer = $this;
$installer->startSetup();

$appTable      = $installer->getTable('xmlconnect/application');
$templateTable = $installer->getTable('xmlconnect/template');
$queueTable    = $installer->getTable('xmlconnect/queue');

foreach (array($appTable, $historyTable, $templateTable, $queueTable) as $table) {
    $installer->run(sprintf('ALTER TABLE `%s` ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci', $table));
}

$connection = $installer->getConnection();

$connection->modifyColumn($appTable, 'name', 'VARCHAR(255) NOT NULL COLLATE utf8_general_ci');
$connection->modifyColumn($appTable, 'code', 'VARCHAR(32) NOT NULL COLLATE utf8_general_ci');
$connection->modifyColumn($appTable, 'type', 'VARCHAR(32) NOT NULL COLLATE utf8_general_ci');

$connection->modifyColumn($templateTable, 'app_code', 'VARCHAR(32) NOT NULL COLLATE utf8_general_ci');
$connection->modifyColumn($templateTable, 'name', 'VARCHAR(255) NOT NULL COLLATE utf8_general_ci');
$connection->modifyColumn($templateTable, 'push_title', 'VARCHAR(141) NOT NULL COLLATE utf8_general_ci');
$connection->modifyColumn($templateTable, 'message_title', 'VARCHAR(255) NOT NULL COLLATE utf8_general_ci');
$connection->modifyColumn($templateTable, 'content', 'TEXT NOT NULL COLLATE utf8_general_ci');

$connection->modifyColumn($queueTable, 'push_title', 'VARCHAR(140) NOT NULL COLLATE utf8_general_ci');
$connection->modifyColumn($queueTable, 'message_title', 'VARCHAR(255) NOT NULL COLLATE utf8_general_ci');
$connection->modifyColumn($queueTable, 'content', 'TEXT NOT NULL COLLATE utf8_general_ci');
$connection->modifyColumn($queueTable, 'type', 'VARCHAR(12) NOT NULL COLLATE utf8_general_ci');
$connection->modifyColumn($queueTable, 'app_code', 'VARCHAR(32) NOT NULL COLLATE utf8_general_ci');

$connection->addKey($appTable, 'UNQ_XMLCONNECT_APPLICATION_CODE', 'code', 'unique');
$connection->addConstraint('FK_APP_CODE', $templateTable, 'app_code', $appTable, 'code');

$installer->endSetup();
