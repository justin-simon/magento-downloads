<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * XmlConnect cms page controller
 *
 * @category    Mage
 * @package     Mage_Xmlconnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_CmsController extends Mage_XmlConnect_Controller_Action
{
    /**
     * Declare content type header
     *
     * @return null
     */
    public function preDispatch()
    {
        parent::preDispatch();
        $this->getResponse()->setHeader('Content-type', 'text/html; charset=UTF-8');
    }

    /**
     * Category list
     *
     * @return null
     */
    public function pageAction()
    {
        $this->loadLayout(false);
        $this->renderLayout();
    }

    /**
     * 3d secure authentication request page
     *
     * @return null
     */
    public function sentinelSecureAction()
    {
        try {
            $method = Mage::getSingleton('checkout/session')->getQuote()->getPayment()->getMethodInstance();
            if ($method->getIsCentinelValidationEnabled()) {
                $centinel = $method->getCentinelValidator();
                if ($centinel && $centinel->shouldAuthenticate()) {
                    /** @var $sentinelBlock Mage_Centinel_Block_Authentication */
                    $sentinelBlock = $this->getLayout()->addBlock('centinel/authentication', 'centinel.frame')
                        ->setTemplate('xmlconnect/centinel/authentication.phtml');
                    $this->getResponse()->setBody($sentinelBlock->toHtml());
                    return;
                }
            }
        } catch (Mage_Core_Exception $e) {
            $this->getResponse()->setBody($e->getMessage());
        } catch (Exception $e) {
            $this->getResponse()->setBody($e->getMessage());
            Mage::logException($e);
        }
    }
}
