<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * XmlConnect offline catalog controller
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_OfflineCatalogController extends Mage_Core_Controller_Front_Action
{
    /**
     * Index action
     *
     * @return null
     */
    public function indexAction()
    {
        /** @var $helper Mage_XmlConnect_Helper_OfflineCatalog */
        $helper = Mage::helper('xmlconnect/offlineCatalog');
        $key = $this->getRequest()->getParam('key', false);
        if (!$key || !$helper->setCurrentDeviceModel($key)) {
            $this->_forward('noRoute');
            return;
        }
        try {
            $this->loadLayout(false);
            Mage::getModel('xmlconnect/offlineCatalog')->exportData();
            $helper->renderXmlObject();
            Mage::getSingleton('core/session')->addSuccess($this->__('Offline catalog export complete.'));
        } catch (Exception $e) {
            Mage::logException($e);
            Mage::getSingleton('core/session')->addError($this->__('Offline catalog export failed.'));
        }
        $this->getResponse()->setBody(Mage::helper('core')->jsonEncode(
            array('result' => Mage::app()->getLayout()->getMessagesBlock()->getGroupedHtml())
        ));
    }
}
