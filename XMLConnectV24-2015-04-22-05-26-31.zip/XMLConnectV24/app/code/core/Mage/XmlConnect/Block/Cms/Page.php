<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Cms Page xml renderer
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Block_Cms_Page extends Mage_Cms_Block_Page
{
    /**
     * Page Id getter
     *
     * @return int
     */
    public function getPageId()
    {
        return $this->getRequest()->getParam('id');
    }
}
