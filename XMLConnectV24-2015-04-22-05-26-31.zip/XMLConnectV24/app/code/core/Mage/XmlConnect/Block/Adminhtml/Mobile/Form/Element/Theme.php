<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * XmlConnect theme form element
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Block_Adminhtml_Mobile_Form_Element_Theme extends Varien_Data_Form_Element_Text
{
    /**
     * Generate themes (colors) html
     *
     * @return string
     */
    public function getHtml()
    {
        $blockClassName = Mage::getConfig()->getBlockClassName('xmlconnect/adminhtml_mobile_edit_tab_design_themes');
        $block = Mage::getModel($blockClassName);
        $block->setThemes($this->getThemes());
        $block->setName($this->getName());
        $block->setValue($this->getValue());
        return $block->toHtml();
    }
}
