<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Authorize.Net through Pbridge Payment method xml renderer
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Block_Checkout_Payment_Method_Pbridge_Authorizenet
    extends Mage_XmlConnect_Block_Checkout_Payment_Method_Pbridge_Abstract
{
    /**
     * Payment model path
     *
     * @var string
     */
    protected $_model = 'authorizenet';
}
