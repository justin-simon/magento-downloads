<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Customers xml renderer block
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Block_Adminhtml_Connect_Dashboard_Customers
    extends Mage_Adminhtml_Block_Dashboard_Tab_Customers_Most
{
    /**
     * Customers count to display
     */
    const CUSTOMERS_COUNT_LIMIT = 5;

    /**
     * Get rid of unnecessary collection initialization
     *
     * @return Mage_XmlConnect_Block_Adminhtml_Connect_Dashboard_Customers
     */
    protected function _prepareCollection()
    {
        return $this;
    }

    /**
     * Init order collection
     *
     * @param int|null $storeId
     * @return Mage_XmlConnect_Block_Adminhtml_Connect_Dashboard_Customers
     */
    protected function _initCollection($storeId)
    {
        /** @var $collection Mage_Reports_Model_Resource_Order_Collection */
        $collection = Mage::getResourceModel('reports/order_collection');
        $collection->groupByCustomer()->addOrdersCount()->joinCustomerName()->setPageSize(self::CUSTOMERS_COUNT_LIMIT);

        $storeFilter = 0;
        if ($storeId) {
            $collection->addAttributeToFilter('store_id', $storeId);
            $storeFilter = 1;
        }

        $collection->addSumAvgTotals($storeFilter)->orderByTotalAmount();
        $this->setCollection($collection);
        return $this;
    }

    /**
     * Clear collection
     *
     * @return Mage_XmlConnect_Block_Adminhtml_Connect_Dashboard_Customers
     */
    protected function _clearCollection()
    {
        $this->_collection = null;
        return $this;
    }

    /**
     * Add customers statistic to xml object
     *
     * @param Mage_XmlConnect_Model_Simplexml_Element $xmlObj
     * @return Mage_XmlConnect_Block_Adminhtml_Connect_Dashboard_Customers
     */
    public function addCustomersToXmlObj(Mage_XmlConnect_Model_Simplexml_Element $xmlObj)
    {
        foreach (Mage::helper('xmlconnect/adminApplication')->getSwitcherList() as $storeId) {
            $this->_clearCollection()->_initCollection($storeId);
            $valuesXml = $xmlObj->addCustomChild('values', null, array(
                'store_id' => $storeId ? $storeId : Mage_XmlConnect_Helper_AdminApplication::ALL_STORE_VIEWS
            ));

            if(!count($this->getCollection()->getItems()) > 0) {
                continue;
            }

            /** @var $orderHelper Mage_XmlConnect_Helper_Adminhtml_Dashboard_Order */
            $orderHelper = Mage::helper('xmlconnect/adminhtml_dashboard_order');

            foreach ($this->getCollection()->getItems() as $item) {
                $itemListXml = $valuesXml->addCustomChild('item');
                $itemListXml->addCustomChild('name', $item->getName(), array(
                    'label' => $this->__('Customer Name')
                ));
                $itemListXml->addCustomChild('orders_count', $item->getOrdersCount(), array(
                    'label' => $this->__('Number of Orders')
                ));
                $itemListXml->addCustomChild(
                    'orders_avg_amount',
                    $orderHelper->preparePrice($item->getOrdersAvgAmount(), $storeId),
                    array('label' => $this->__('Average Order Amount'))
                );
                $itemListXml->addCustomChild(
                    'orders_sum_amount',
                    $orderHelper->preparePrice($item->getOrdersSumAmount(), $storeId),
                    array('label' => $this->__('Total Order Amount'))
                );
            }
        }
        return $this;
    }
}
