<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Customer order item xml renderer for grouped product type
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Block_Customer_Order_Item_Renderer_Grouped extends Mage_Sales_Block_Order_Item_Renderer_Grouped
{
    /**
     * Default product type
     */
    const DEFAULT_PRODUCT_TYPE = 'default';

    /**
     * Add item to XML object
     * (get from template: sales/order/items/renderer/default.phtml)
     *
     * @param Mage_XmlConnect_Model_Simplexml_Element $orderItemXmlObj
     * @return null
     */
    public function addItemToXmlObject(Mage_XmlConnect_Model_Simplexml_Element $orderItemXmlObj)
    {
        $item = $this->getItem()->getOrderItem();
        if (!$item) {
            $item = $this->getItem();
        }
        $productType = $item->getRealProductType();
        if (!$productType) {
            $productType = self::DEFAULT_PRODUCT_TYPE;
        }
        $renderer = $this->getRenderedBlock()->getItemRenderer($productType);
        $renderer->setItem($this->getItem())->setNewApi($this->getNewApi());
        $renderer->addItemToXmlObject($orderItemXmlObj);
    }
}
