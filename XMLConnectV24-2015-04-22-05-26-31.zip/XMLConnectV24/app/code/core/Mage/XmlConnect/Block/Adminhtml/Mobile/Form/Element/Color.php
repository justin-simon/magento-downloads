<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Xmlconnect color form element
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Block_Adminhtml_Mobile_Form_Element_Color extends Varien_Data_Form_Element_Text
{
    /**
     * Return html code for current block
     *
     * @return mixed|string
     */
    public function getHtml()
    {
        $this->addClass('color {required:false,hash:true}');
        return parent::getHtml();
    }
}
