<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * PayPal MECL Shopping cart review xml renderer
 *
 * @category    Mage
 * @package     Mage_Xmlconnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Block_Cart_Paypal_Mecl_Review extends Mage_Paypal_Block_Express_Review
{
    /**
     * Render PayPal MECL details xml
     *
     * @return string xml
     */
    protected function _toHtml()
    {
        /** @var $reviewXmlObj Mage_XmlConnect_Model_Simplexml_Element */
        $reviewXmlObj = Mage::getModel('xmlconnect/simplexml_element', '<mecl_cart_details></mecl_cart_details>');

        if ($this->getPaypalMessages()) {
            $reviewXmlObj->addChild('paypal_message', implode('\n', $this->getPaypalMessages()));
        }

        if ($this->getShippingAddress()) {
            $shipping = Mage::helper('xmlconnect')->trimLineBreaks($this->getShippingAddress()->format('text'));
            $reviewXmlObj->addCustomChild('shipping_address', $shipping, array(
                'label' => $this->__('Shipping Address')
            ));
        }

        if ($this->_quote->isVirtual()) {
            $reviewXmlObj->addCustomChild('shipping_method', null, array(
                'label' => $this->__('No shipping method required.')
            ));
        } elseif ($this->getCanEditShippingMethod() || !$this->getCurrentShippingRate()) {
            if ($groups = $this->getShippingRateGroups()) {
                $currentRate = $this->getCurrentShippingRate();
                foreach ($groups as $code => $rates) {
                    foreach ($rates as $rate) {
                        if ($currentRate === $rate) {
                            $reviewXmlObj->addCustomChild('shipping_method', null, array(
                                'rate' => strip_tags($this->renderShippingRateOption($rate)),
                                'label' => $this->getCarrierName($code)
                            ));
                            break(2);
                        }
                    }
                }
            }
        }
        $reviewXmlObj->addCustomChild('payment_method', $this->escapeHtml($this->getPaymentMethodTitle()), array(
            'label' => $this->__('Payment Method')
        ));
        $billing = Mage::helper('xmlconnect')->trimLineBreaks($this->getBillingAddress()->format('text'));
        $reviewXmlObj->addCustomChild('billing_address', $billing, array(
            'label' => $this->__('Billing Address'),
            'payer_email' => $this->__('Payer Email: %s', $this->getBillingAddress()->getEmail())
        ));

        $this->getChild('details')->addDetailsToXmlObj($reviewXmlObj);

        $agreements = $this->getChildHtml('agreements');
        if ($agreements) {
            $agreementsXmlObj = Mage::getModel('xmlconnect/simplexml_element', $agreements);
            $reviewXmlObj->appendChild($agreementsXmlObj);
        }

        return $reviewXmlObj->asNiceXml();
    }
}
