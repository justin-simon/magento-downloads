<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Orders chart data xml renderer block
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Block_Adminhtml_Connect_Dashboard_GraphOrderData
    extends Mage_XmlConnect_Block_Adminhtml_Connect_Dashboard_GraphDataAbstract
{
    /**
     * Initialize object
     */
    public function __construct()
    {
        $this->setHtmlId('orders');
        parent::__construct();
    }

    /**
     * Prepare chart data
     *
     * @return null
     */
    protected function _prepareData()
    {
        $this->setDataHelperName('xmlconnect/adminhtml_dashboard_order');
        $this->setDataRows('quantity');
        $this->_axisMaps = array('x' => 'range', 'y' => 'quantity');
        parent::_prepareData();
    }

    /**
     * Add order chart data to xml object
     *
     * @param Mage_XmlConnect_Model_Simplexml_Element $xmlObj
     * @return Mage_XmlConnect_Block_Adminhtml_Connect_Dashboard_GraphOrderData
     */
    public function addOrderChartDataToXmlObj(Mage_XmlConnect_Model_Simplexml_Element $xmlObj)
    {
        $this->_xmlObj = $xmlObj->addCustomChild('chart_data_details', null, array('id' => 'orders'));
        $this->_addAllStoreData();
        return $this;
    }
}
