<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Admin application config renderer
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Block_Adminhtml_Connect_Config extends Mage_Core_Block_Abstract
{
    /**
     * Render login form xml
     *
     * @return string
     */
    protected function _toHtml()
    {
        /** @var Mage_XmlConnect_Model_Simplexml_Element $configXmlObj */
        $configXmlObj = Mage::getModel('xmlconnect/simplexml_element', '<configuration></configuration>');
        $this->_addLocalization($configXmlObj);
        $configXmlObj->addCustomChild('xmlconnect_version', Mage::getConfig()->getNode(
            Mage_XmlConnect_Model_Application::XML_PATH_MODULE_VERSION
        ));

        return $configXmlObj->asNiceXml();
    }

    /**
     * Add localization data to xml object
     *
     * @param Mage_XmlConnect_Model_Simplexml_Element $xml
     * @return Mage_XmlConnect_Block_Adminhtml_Connect_Config
     */
    protected function _addLocalization(Mage_XmlConnect_Model_Simplexml_Element $xml)
    {
        /** @var $translateHelper Mage_XmlConnect_Helper_Translate */
        $translateHelper = Mage::helper('xmlconnect/translate');
        $xml->addCustomChild('localization', $this->getUrl('*/*/localization'), array(
            'hash' => sha1(serialize($translateHelper->getLocalizationArray()))
        ));
        return $this;
    }
}
