<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Cart totals gift card renderer
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_Xmlconnect_Block_Cart_CartTotals_Nodes_Giftcardaccount extends Mage_Checkout_Block_Total_Default
{
    /**
     * Add gift card balance to xml
     *
     * @return Mage_XmlConnect_Model_Simplexml_Element
     */
    protected function _toHtml()
    {
        if (!$this->getTotal()->getValue()) {
            return;
        }
        /** @var $cartXmlObject Mage_XmlConnect_Model_Simplexml_Element */
        $cartXmlObject = $this->getCartObject();
        $cards = $this->getTotal()->getGiftCards();
        if (!$cards) {
            $cards = $this->getQuoteGiftCards();
        }
        $code = $this->getTotal()->getCode();

        /** @var $giftCardsXmlObj Mage_XmlConnect_Model_Simplexml_Element */
        $giftCardsXmlObj = $cartXmlObject->addCustomChild($code);

        foreach ($cards as $cardCode) {
            $giftCardValue = Mage::helper('xmlconnect')->formatPriceForXml($cardCode['a']);
            $formattedValue = $this->getQuote()->getStore()->formatPrice($giftCardValue, false);
            $giftCardsXmlObj->addCustomChild('item', '-' . $giftCardValue, array(
                'id' => $code . '_' . $cardCode['i'],
                'label' => $this->__('Gift Card (%s)', $cardCode['c']),
                'formatted_value' => '-' . $formattedValue,
                'code' => $cardCode['c']
            ));
        }
        return $giftCardsXmlObj;
    }
}
