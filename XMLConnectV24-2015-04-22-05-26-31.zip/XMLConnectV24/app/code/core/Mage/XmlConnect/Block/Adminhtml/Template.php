<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * XmlConnect AirMail message template grid
 *
 * @category   Mage
 * @package    Mage_XmlConnect
 * @author     Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Block_Adminhtml_Template extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    /**
     * Class constructor
     */
    public function __construct()
    {
        $this->_blockGroup = 'xmlconnect';
        $this->_controller = 'adminhtml_template';
        $this->_headerText = $this->__('AirMail templates');

        parent::__construct();
        $this->removeButton('add');
    }

    /**
     * Prepare layout
     * Add new button
     *
     * @return Mage_Adminhtml_Block_Widget_Grid_Container
     */
    protected function _prepareLayout()
    {
        $this->_addButton('add_new', array(
            'label'   => $this->__('Add New Template'),
            'onclick' => "setLocation('{$this->getUrl('*/*/newTemplate')}')",
            'class'   => 'add'
        ));

        return parent::_prepareLayout();
    }
}
