<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Pbridge result payment block
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Block_Checkout_Pbridge_Result extends Mage_Core_Block_Abstract
{
    /**
     * Return url for redirect with params of Payment Bridge incoming data
     *
     * @return string
     */
    public function getPbridgeParamsAsUrl()
    {
        $pbParams = Mage::helper('enterprise_pbridge')->getPbridgeParams();
        $params = array_merge(
            array('_nosid' => true, 'method' => 'pbridge_' . $pbParams['original_payment_method']),
            $pbParams
        );
        return Mage::getUrl('xmlconnect/pbridge/output', $params);
    }
}
