<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Top search terms xml renderer block
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Block_Adminhtml_Connect_Dashboard_TopSearchTerms
    extends Mage_Adminhtml_Block_Dashboard_Searches_Top
{
    /**
     * Search terms count to display
     */
    const TERMS_COUNT_LIMIT = 5;

    /**
     * Get rid of unnecessary collection initialization
     *
     * @return Mage_XmlConnect_Block_Adminhtml_Connect_Dashboard_TopSearchTerms
     */
    protected function _prepareCollection()
    {
        return $this;
    }

    /**
     * Init last search terms collection
     *
     * @param int|null $storeId
     * @return Mage_XmlConnect_Block_Adminhtml_Connect_Dashboard_TopSearchTerms
     */
    protected function _initCollection($storeId)
    {
        if (!Mage::helper('core')->isModuleEnabled('Mage_CatalogSearch')) {
            return $this;
        }
        /** @var $_collection Mage_CatalogSearch_Model_Resource_Query_Collection */
        $this->_collection = Mage::getModel('catalogsearch/query')->getResourceCollection();
        $this->_collection->setPopularQueryFilter($storeId ? $storeId : '')->setPageSize(self::TERMS_COUNT_LIMIT);
        $this->setCollection($this->_collection);
        return $this;
    }

    /**
     * Clear collection
     *
     * @return Mage_XmlConnect_Block_Adminhtml_Connect_Dashboard_TopSearchTerms
     */
    protected function _clearCollection()
    {
        $this->_collection = null;
        return $this;
    }

    /**
     * Add last search terms info to xml object
     *
     * @param Mage_XmlConnect_Model_Simplexml_Element $xmlObj
     * @return Mage_XmlConnect_Block_Adminhtml_Connect_Dashboard_TopSearchTerms
     */
    public function addTopSearchTermsToXmlObj(Mage_XmlConnect_Model_Simplexml_Element $xmlObj)
    {
        foreach (Mage::helper('xmlconnect/adminApplication')->getSwitcherList() as $storeId) {
            $this->_clearCollection()->_initCollection($storeId);
            $valuesXml = $xmlObj->addCustomChild('values', null, array(
                'store_id' => $storeId ? $storeId : Mage_XmlConnect_Helper_AdminApplication::ALL_STORE_VIEWS
            ));

            if(!count($this->getCollection()->getItems()) > 0) {
                continue;
            }

            foreach ($this->getCollection()->getItems() as $item) {
                $itemListXml = $valuesXml->addCustomChild('item');
                $itemListXml->addCustomChild('name', $item->getName(), array(
                    'label' => $this->__('Search Term')
                ));
                $itemListXml->addCustomChild('num_results', $item->getNumResults(), array(
                    'label' => $this->__('Results')
                ));
                $itemListXml->addCustomChild('popularity', $item->getPopularity(), array(
                    'label' => $this->__('Number of Uses')
                ));
            }
        }
        return $this;
    }
}
