<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Admin Application Settings Tabs block
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Block_Adminhtml_Admin_Application_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{
    /**
     * Setting tab id, DOM destination element id, title
     */
    public function __construct()
    {
        parent::__construct();
        $this->setId('admin_application_app_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle($this->__('Admin Mobile Application'));
    }

    /**
     * Preparing global layout
     *
     * @return Mage_Core_Block_Abstract
     */
    protected function _prepareLayout()
    {
        $this->addTab('set', array(
            'label'     => $this->__('Settings'),
            'content'   => $this->getLayout()->createBlock('xmlconnect/adminhtml_admin_application_edit_tab_settings')
                ->toHtml(),
            'active'    => true
        ));
        return parent::_prepareLayout();
    }
}
