<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Simple product options xml renderer
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Block_Catalog_Product_Options_Simple extends Mage_XmlConnect_Block_Catalog_Product_Options
{
    /**
     * Generate simple product options xml
     *
     * @param Mage_Catalog_Model_Product $product
     * @param bool $isObject
     * @return string | Mage_XmlConnect_Model_Simplexml_Element
     */
    public function getProductOptionsXml(Mage_Catalog_Model_Product $product, $isObject = false)
    {
        $xmlModel = $this->getProductCustomOptionsXmlObject($product);
        return $isObject ? $xmlModel : $xmlModel->asNiceXml();
    }
}
