<?php
/**
  * Copyright © 2015 Magento. All rights reserved.
  * See COPYING.txt for license details.
  */

/**
 * Customer order Customer balance totals xml renderer
 *
 * @category    Mage
 * @package     Mage_XmlConnect
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Mage_XmlConnect_Block_Customer_Order_Totals_Customerbalance
    extends Enterprise_CustomerBalance_Block_Sales_Order_Customerbalance
{
    /**
     * Add order total rendered to XML object
     *
     * @param $totalsXml Mage_XmlConnect_Model_Simplexml_Element
     * @return null
     */
    public function addToXmlObject(Mage_XmlConnect_Model_Simplexml_Element $totalsXml)
    {
        if ($this->getNewApi()) {
            $this->addToXmlObjectApi23($totalsXml);
            return;
        }

        $balance = $this->getSource()->getCustomerBalanceAmount();
        if ($balance) {
            $totalsXml->addCustomChild(
                $this->getTotal()->getCode(),
                '-' . $this->_formatPrice($balance),
                array('label' => Mage::helper('enterprise_giftcardaccount')->__('Store Credit'))
            );
        }
    }

    /**
     * Add order total rendered to XML object. Api version 23
     *
     * @param $totalsXml Mage_XmlConnect_Model_Simplexml_Element
     * @return null
     */
    public function addToXmlObjectApi23(Mage_XmlConnect_Model_Simplexml_Element $totalsXml)
    {
        $balance = $this->getSource()->getCustomerBalanceAmount();
        if ($balance) {
            $totalsXml->addCustomChild('item', '-' . $this->_formatPrice($balance), array(
                'id' => $this->getTotal()->getCode(),
                'label' => Mage::helper('enterprise_giftcardaccount')->__('Store Credit')
            ));
        }
    }

    /**
     * Format price using order currency
     *
     * @param   float $amount
     * @return  string
     */
    protected function _formatPrice($amount)
    {
        return Mage::helper('xmlconnect/customer_order')->formatPrice($this, $amount);
    }
}
